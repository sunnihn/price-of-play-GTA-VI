import { useCallback, useRef, useState } from 'react';
import Backdrop from './components/Backdrop.jsx';
import DetailPanel from './components/DetailPanel.jsx';
import Header from './components/Header.jsx';
import Legend from './components/Legend.jsx';
import Tooltip from './components/Tooltip.jsx';
import WorldMap from './components/WorldMap.jsx';
import { useReducedMotion } from './hooks/useReducedMotion.js';
import { countryByIso } from './lib/data.js';

export default function App() {
  const reducedMotion = useReducedMotion();
  const tooltipRef = useRef(null);
  const [selectedIso, setSelectedIso] = useState(null);
  // `key` changes on every click so re-clicking the same clock spins it again.
  const [spin, setSpin] = useState({ key: 0, targets: [] });

  const handleSelect = useCallback((iso, targets) => {
    tooltipRef.current?.hide();
    setSelectedIso(iso);
    setSpin((prev) => ({ key: prev.key + 1, targets }));
  }, []);

  const handleBack = useCallback(() => {
    setSelectedIso(null);
    setSpin((prev) => ({ key: prev.key, targets: [] }));
  }, []);

  const selected = selectedIso ? countryByIso[selectedIso] : null;

  return (
    <main className="relative h-full w-full">
      <Backdrop />
      <WorldMap
        selectedIso={selectedIso}
        spin={spin}
        onSelect={handleSelect}
        reducedMotion={reducedMotion}
        tooltipRef={tooltipRef}
        panelOpen={Boolean(selected)}
        onReset={handleBack}
      />
      <Header />
      <Legend />
      {!selected && (
        <p className="pointer-events-none absolute bottom-5 left-1/2 z-10 hidden -translate-x-1/2 rounded-full border border-white/10 bg-navy/70 px-4 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-soft/70 backdrop-blur md:block">
          Klik jam atau negara · gulir untuk zoom · seret untuk menggeser
        </p>
      )}
      {selected && (
        <DetailPanel
          key={selected.iso3}
          country={selected}
          spinKey={spin.targets.includes(selected.iso3) ? spin.key : 0}
          reducedMotion={reducedMotion}
          onBack={handleBack}
        />
      )}
      <Tooltip ref={tooltipRef} />
    </main>
  );
}
