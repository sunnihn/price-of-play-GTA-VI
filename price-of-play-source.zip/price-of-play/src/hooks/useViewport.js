import { useCallback, useEffect, useRef } from 'react';
import { MAP, VIEWBOX } from '../lib/geo.js';

const K_MIN = 1;
const K_MAX = 10;
const MARGIN = 120;
const WHEEL_SPEED = 11; // higher = camera catches up with the target faster
const FLY_SPEED = 4.2;

const clampK = (k) => Math.min(K_MAX, Math.max(K_MIN, k));

function clampView({ x, y, k }) {
  const kk = clampK(k);
  return {
    k: kk,
    x: Math.min(MARGIN, Math.max(MAP.width * (1 - kk) - MARGIN, x)),
    y: Math.min(MARGIN, Math.max(MAP.height * (1 - kk) - MARGIN, y)),
  };
}

/**
 * Pan / zoom with a smoothed camera: input only moves a *target*, and every frame the
 * visible view eases towards it (exponential damping, frame-rate independent).
 * That keeps wheel zoom, buttons and fly-to transitions fluid. Coordinates are map units.
 */
export function useViewport(svgRef, { reducedMotion, onFrame }) {
  const current = useRef({ x: 0, y: 0, k: 1 });
  const target = useRef({ x: 0, y: 0, k: 1 });
  const onFrameRef = useRef(onFrame);
  onFrameRef.current = onFrame;
  const speed = useRef(WHEEL_SPEED);
  const frame = useRef(0);
  const lastTime = useRef(0);
  const drag = useRef(null);
  const moved = useRef(false);

  /** Store the new view and let the map write it to the DOM directly (no React render per frame). */
  const commit = useCallback((next) => {
    current.current = next;
    onFrameRef.current?.(next);
  }, []);

  const step = useCallback((now) => {
    const dt = Math.min(0.05, (now - lastTime.current) / 1000 || 0.016);
    lastTime.current = now;
    const a = 1 - Math.exp(-speed.current * dt);
    const c = current.current;
    const t = target.current;
    const lnK = Math.log(c.k);
    const dLnK = Math.log(t.k) - lnK; // zoom eases in log space so it feels even
    const done = Math.abs(t.x - c.x) < 0.02 && Math.abs(t.y - c.y) < 0.02 && Math.abs(dLnK) < 0.0004;
    if (done) {
      commit({ ...t });
      frame.current = 0;
      return;
    }
    commit({ x: c.x + (t.x - c.x) * a, y: c.y + (t.y - c.y) * a, k: Math.exp(lnK + dLnK * a) });
    frame.current = requestAnimationFrame(step);
  }, [commit]);

  const moveTo = useCallback((next, velocity) => {
    target.current = clampView(next);
    speed.current = velocity;
    if (reducedMotion) { commit({ ...target.current }); return; }
    if (!frame.current) {
      lastTime.current = performance.now();
      frame.current = requestAnimationFrame(step);
    }
  }, [commit, reducedMotion, step]);

  const stop = () => {
    cancelAnimationFrame(frame.current);
    frame.current = 0;
  };

  /** Client pixels -> viewBox units (accounts for "meet" letterboxing). */
  const toViewBox = useCallback((clientX, clientY) => {
    const rect = svgRef.current.getBoundingClientRect();
    const scale = Math.min(rect.width / VIEWBOX.width, rect.height / VIEWBOX.height);
    const offX = (rect.width - VIEWBOX.width * scale) / 2;
    const offY = (rect.height - VIEWBOX.height * scale) / 2;
    return {
      x: (clientX - rect.left - offX) / scale + VIEWBOX.x,
      y: (clientY - rect.top - offY) / scale + VIEWBOX.y,
      scale,
    };
  }, [svgRef]);

  /** Zoom around a point; computed against the target so rapid wheel ticks accumulate smoothly. */
  const zoomAt = useCallback((px, py, factor) => {
    const { x, y, k } = target.current;
    const nextK = clampK(k * factor);
    const ratio = nextK / k;
    moveTo({ k: nextK, x: px - (px - x) * ratio, y: py - (py - y) * ratio }, WHEEL_SPEED);
  }, [moveTo]);

  /** Fly the camera so `anchor` sits in the open part of the screen (left of the panel). */
  const focusOn = useCallback((anchor, k = 4.5, center = [380, 230]) => {
    moveTo({ k, x: center[0] - k * anchor[0], y: center[1] - k * anchor[1] }, FLY_SPEED);
  }, [moveTo]);

  const reset = useCallback(() => moveTo({ x: 0, y: 0, k: 1 }, FLY_SPEED), [moveTo]);

  const zoomBy = useCallback((factor) => {
    zoomAt(VIEWBOX.x + VIEWBOX.width / 2, VIEWBOX.y + VIEWBOX.height / 2, factor);
  }, [zoomAt]);

  // Wheel must be a non-passive native listener to prevent page scroll.
  useEffect(() => {
    const svg = svgRef.current;
    const onWheel = (e) => {
      e.preventDefault();
      const p = toViewBox(e.clientX, e.clientY);
      zoomAt(p.x, p.y, Math.exp(-e.deltaY * 0.002));
    };
    svg.addEventListener('wheel', onWheel, { passive: false });
    return () => svg.removeEventListener('wheel', onWheel);
  }, [svgRef, toViewBox, zoomAt]);

  useEffect(() => stop, []);

  const pointerHandlers = {
    onPointerDown: (e) => {
      if (e.button !== 0) return;
      stop();
      target.current = { ...current.current };
      moved.current = false;
      drag.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
    },
    onPointerMove: (e) => {
      const d = drag.current;
      if (!d || d.id !== e.pointerId) return;
      const dx = e.clientX - d.x;
      const dy = e.clientY - d.y;
      if (!moved.current && Math.hypot(dx, dy) < 5) return;
      if (!moved.current) e.currentTarget.setPointerCapture(e.pointerId);
      moved.current = true;
      const { scale } = toViewBox(e.clientX, e.clientY);
      d.x = e.clientX;
      d.y = e.clientY;
      const c = current.current;
      const next = clampView({ k: c.k, x: c.x + dx / scale, y: c.y + dy / scale });
      target.current = next; // dragging is 1:1, no easing lag under the finger
      commit(next);
    },
    onPointerUp: (e) => {
      if (drag.current?.id === e.pointerId) drag.current = null;
    },
  };

  /** Click handlers call this to ignore the click that ends a drag. */
  const wasDragged = () => moved.current;

  return { viewRef: current, focusOn, reset, zoomBy, pointerHandlers, wasDragged };
}
