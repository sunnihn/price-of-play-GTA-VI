import { useEffect, useState } from 'react';

const easeInOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - ((-2 * t + 2) ** 3) / 2);

/**
 * Progress (0..1) of a clock "spin". Every time `spinKey` changes to a truthy value the
 * progress restarts at 0 and eases up to 1. Resting state is 1.
 */
export function useSpin(spinKey, durationMs, disabled = false) {
  const [progress, setProgress] = useState(1);

  useEffect(() => {
    if (!spinKey || disabled) {
      setProgress(1);
      return undefined;
    }
    let frame;
    let start;
    const step = (now) => {
      start ??= now;
      const t = Math.min(1, (now - start) / durationMs);
      setProgress(easeInOut(t));
      if (t < 1) frame = requestAnimationFrame(step);
    };
    setProgress(0);
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [spinKey, durationMs, disabled]);

  return progress;
}

/** Spin duration grows with the hours so bigger numbers feel heavier. */
export const spinDuration = (hours) => Math.min(4200, 1500 + hours * 35);
