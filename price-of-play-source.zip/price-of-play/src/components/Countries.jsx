import { memo } from 'react';
import { countryByIso, hoursScale } from '../lib/data.js';
import { EXT_COLOR, MISSING_COLOR, OTHER_COLOR, lighten, mix } from '../lib/palette.js';

/** Gradient definitions: one soft top-to-bottom gradient per country, derived from its hours colour. */
export function CountryGradients({ countries }) {
  return (
    <defs>
      {countries.map((c) => {
        const base = c.hours !== null ? hoursScale.color(c.hours) : c.extended ? mix(MISSING_COLOR, EXT_COLOR, 0.5) : MISSING_COLOR;
        return (
          <linearGradient key={c.iso3} id={`cg-${c.iso3}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={lighten(base, c.hours === null ? 0.12 : 0.3)} />
            <stop offset="1" stopColor={base} />
          </linearGradient>
        );
      })}
    </defs>
  );
}

function Countries({ shapes, selectedIso, onSelect, onHover, onLeave }) {
  return (
    <g>
      {shapes.map((s, i) => {
        const country = s.iso3 ? countryByIso[s.iso3] : null;
        if (!country) {
          return <path key={`o${i}`} d={s.d} fill={OTHER_COLOR} stroke="#2a3558" style={{ strokeWidth: 'calc(var(--hairline, 1) * 0.5)' }} pointerEvents="none" />;
        }
        const selected = s.iso3 === selectedIso;
        return (
          <path
            key={s.iso3}
            d={s.d}
            className="country"
            fill={`url(#cg-${s.iso3})`}
            stroke={selected ? '#ffffff' : 'rgba(255,255,255,0.28)'}
            style={{ strokeWidth: `calc(var(--hairline, 1) * ${selected ? 2 : 0.6})` }}
            onClick={() => onSelect(s.iso3, [s.iso3])}
            onPointerMove={(e) => onHover(country, e)}
            onPointerLeave={onLeave}
          />
        );
      })}
    </g>
  );
}

export default memo(Countries);
