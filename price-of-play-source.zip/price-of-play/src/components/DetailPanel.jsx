import { useState } from 'react';
import ClockFace from './ClockFace.jsx';
import SourcesModal from './SourcesModal.jsx';
import { useSpin, spinDuration } from '../hooks/useSpin.js';
import { stats, hoursScale } from '../lib/data.js';
import { EXT_COLOR } from '../lib/palette.js';
import { fmtDecimal, fmtHours, fmtInt, fmtMoney, fmtPercent, fmtUsd } from '../lib/format.js';
import { TAX_LABEL, WAGE_STATUS_LABEL, qualityLabel } from '../lib/labels.js';

const TONE = { ok: 'bg-cyan-neon/15 text-cyan-neon', warn: 'bg-violet/25 text-violet-200', bad: 'bg-hot-pink/20 text-hot-pink' };
const NO_DATA = 'DATA BELUM TERSEDIA';

function Section({ title, children }) {
  return (
    <section className="rounded-xl bg-white/[0.04] p-3">
      <h3 className="text-xs font-bold tracking-widest text-hot-pink">{title}</h3>
      <dl className="mt-1.5 space-y-1.5">{children}</dl>
    </section>
  );
}

function Row({ label, value, hint }) {
  const missing = value === null || value === undefined;
  return (
    <div className="flex items-baseline justify-between gap-3 text-[13px]">
      <dt className="text-soft/60" title={hint}>{label}</dt>
      <dd className={`text-right font-semibold ${missing ? 'text-[10px] tracking-wide text-soft/40' : 'text-soft'}`}>{missing ? NO_DATA : value}</dd>
    </div>
  );
}

/** Page 2: details of the selected country, with a big alarm clock that counts up on every spin. */
export default function DetailPanel({ country, spinKey, reducedMotion, onBack }) {
  const [showSources, setShowSources] = useState(false);
  const { analysis: a, master: m, hours, extended: ext } = country;
  const hasHours = hours !== null;
  const hasExt = !hasHours && Boolean(ext);
  const clockHours = hasHours ? hours : hasExt ? ext.hours : null;
  const progress = useSpin(spinKey, spinDuration(clockHours ?? 10), reducedMotion);
  const shown = (clockHours ?? 0) * progress;
  const color = hasHours ? hoursScale.color(hours) : hasExt ? EXT_COLOR : '#2b3150';
  const quality = a ? qualityLabel(a.quality_flag) : null;
  const priceInUsdStore = m.currency_code === 'USD' && m.country_lcu !== 'USD';

  return (
    <aside className="absolute inset-x-2 bottom-2 z-20 flex max-h-[62vh] flex-col overflow-hidden rounded-2xl border border-white/12 bg-navy/90 shadow-[0_0_40px_rgba(139,54,217,0.35)] md:inset-y-3 md:left-auto md:right-3 md:max-h-none md:w-[368px]">
      <div className="overflow-y-auto p-4">
        <button type="button" onClick={onBack} className="text-xs font-bold uppercase tracking-wider text-soft/70 hover:text-hot-pink">
          ← Kembali ke peta
        </button>

        <div className="mt-2 flex items-center gap-3">
          <svg viewBox="-30 -36 60 66" className="h-28 w-28 shrink-0" aria-hidden="true">
            <ClockFace color={color} hourAngle={shown * 30} minuteAngle={shown * 360} alarm ringing={progress < 1} />
          </svg>
          <div className="min-w-0">
            <p className="text-2xl font-extrabold leading-tight text-soft">{country.name.toUpperCase()}</p>
            <p className="text-[11px] uppercase tracking-wider text-soft/55">{country.continent}</p>
            {hasHours ? (
              <p className="mt-1 text-5xl font-extrabold leading-none text-hot-pink drop-shadow-[0_0_14px_rgba(255,45,141,0.6)]">
                {fmtHours(shown)} <span className="text-xl font-bold">JAM</span>
              </p>
            ) : hasExt ? (
              <p className="mt-1 text-5xl font-extrabold leading-none text-orange-hot drop-shadow-[0_0_14px_rgba(255,154,77,0.55)]">
                {fmtHours(shown)} <span className="text-xl font-bold">JAM</span>
              </p>
            ) : (
              <p className="mt-2 text-sm font-bold tracking-wide text-soft/60">{NO_DATA}</p>
            )}
          </div>
        </div>

        {hasHours ? (
          <p className="mt-2 text-xs text-soft/65">
            <span className="font-bold tracking-wider text-cyan-neon">ESTIMASI JAM KERJA</span> untuk memperoleh uang sebesar harga GTA VI.
            {' '}Peringkat #{country.rank} dari {stats.comparable} (#1 = paling sedikit jam).
          </p>
        ) : hasExt ? (
          <p className="mt-2 text-xs text-soft/65">
            <span className="font-bold tracking-wider text-orange-hot">TAMPILAN TERPISAH</span> Data upah rata-rata ILO belum ada untuk negara ini,
            jadi jam di atas dihitung dari upah minimum. Angka ini menggambarkan pekerja berupah minimum, bukan pekerja rata-rata,
            dan tidak masuk peringkat utama.
          </p>
        ) : (
          <p className="mt-2 text-xs text-soft/65">{country.missingReason ?? 'Data pembanding tidak lengkap.'} Hanya harga yang ditampilkan.</p>
        )}

        <div className="mt-3 space-y-2.5">
          <Section title="HARGA GTA VI">
            <Row label="Edisi Standard" value={fmtMoney(m.gta_standard_price, m.currency_code)} />
            <Row label="Setara USD" value={fmtUsd(m.gta_standard_usd)} hint="Dikonversi oleh sumber harga" />
            <Row label="Platform" value={m.platform} />
            <Row label="Dicek" value={m.price_checked_date} />
            <Row label="Pajak" value={TAX_LABEL[m.tax_included] ?? m.tax_included} />
            {priceInUsdStore && <Row label="Catatan" value="Harga toko dalam USD" />}
          </Section>

          {hasExt && (
            <Section title="UPAH MINIMUM (TAMPILAN TERPISAH)">
              <Row label="Upah minimum" value={`${fmtDecimal(ext.wage_value)} ${ext.wage_currency} per ${ext.wage_period === 'hour' ? 'jam' : 'bulan'}`} />
              {ext.wage_period !== 'hour' && <Row label="Setara per jam" value={`${fmtDecimal(ext.hourly_wage)} ${ext.wage_currency}`} hint="Upah bulanan dibagi rata-rata jam kerja per bulan" />}
              <Row label="Tahun" value={ext.year} />
              <Row label="Dasar" value={ext.method_id} />
              <Row label="Berlaku untuk" value={ext.group_id} />
              <Row label="Sumber" value={ext.verification_id} />
              <Row label="Urutan di antara 13 negara" value={`#${ext.rank} / 13`} hint="Hanya dibandingkan dengan negara tampilan terpisah lain" />
              {ext.note_id && <p className="pt-1 text-[11px] leading-snug text-soft/60">{ext.note_id}</p>}
              {ext.source_url && (
                <a href={ext.source_url} target="_blank" rel="noreferrer" className="block break-all text-[11px] font-semibold text-cyan-neon underline-offset-2 hover:underline">Buka sumber upah</a>
              )}
            </Section>
          )}

          <Section title="PENDAPATAN PEKERJA">
            <Row label="Rata-rata per jam" value={a ? `${fmtDecimal(a.avg_hourly_earnings_intl_usd)} int'l-$` : null} hint="Dolar internasional harga 2021 (PPP)" />
            <Row label="Jenis pendapatan" value={a ? 'Bruto, seluruh pekerja' : null} />
            <Row label="Tahun referensi" value={a?.wage_year ?? null} />
            <Row label="Status data" value={a ? WAGE_STATUS_LABEL[a.wage_status] ?? a.wage_status : null} />
          </Section>

          <Section title="ESTIMASI WAKTU KERJA">
            <Row label="Total jam kerja" value={hasHours ? `${fmtHours(hours)} jam` : null} />
            <Row label="Estimasi hari kerja" value={a ? `${fmtDecimal(a.working_days_required)} hari` : null} hint="Jam dibagi rata-rata jam kerja harian (turunan)" />
            <Row label="Harga vs pendapatan bulanan" value={a ? fmtPercent(a.game_price_monthly_ratio) : null} hint="Pendapatan bulanan adalah estimasi" />
            <Row label="Peringkat global" value={hasHours ? `#${country.rank} / ${stats.comparable}` : null} />
          </Section>

          <Section title="KONDISI EKONOMI">
            <Row label="PDB per kapita (PPP)" value={m.gdp_per_capita_ppp ? `US$ ${fmtInt(m.gdp_per_capita_ppp)}` : null} hint="Pendapatan ekonomi per kapita yang disesuaikan dengan daya beli" />
            <Row label="Inflasi" value={m.inflation_rate !== null && m.inflation_rate !== undefined ? `${fmtHours(m.inflation_rate)}% (${m.inflation_year})` : null} hint="Kenaikan harga tahunan" />
            <Row label="Indeks biaya hidup" value={m.cost_of_living_index} />
            <Row label="Indeks daya beli" value={m.purchasing_power_index} />
          </Section>
        </div>

        {hasExt && (
          <p className={`mt-3 inline-block rounded-full px-3 py-1 text-[11px] font-semibold ${ext.comparability === 'Low' ? TONE.bad : TONE.warn}`}>
            {ext.comparability === 'Low' ? 'Keterbandingan rendah: upah hanya berlaku untuk sebagian pekerja' : 'Keterbandingan terbatas: ini upah minimum, bukan rata-rata'}
          </p>
        )}
        {quality && (
          <p className={`mt-3 inline-block rounded-full px-3 py-1 text-[11px] font-semibold ${TONE[quality.tone]}`}>{quality.text}</p>
        )}
        <button type="button" onClick={() => setShowSources(true)} className="mt-3 block text-xs font-semibold text-cyan-neon underline-offset-2 hover:underline">
          Sumber dan catatan data
        </button>
      </div>
      {showSources && <SourcesModal onClose={() => setShowSources(false)} />}
    </aside>
  );
}
