/** Vice City sky: sunset glow, ocean gradient and a few slow floating particles. */
const PARTICLES = Array.from({ length: 16 }, (_, i) => ({
  left: (i * 37) % 100,
  size: 2 + (i % 3),
  duration: 22 + (i % 5) * 6,
  delay: -((i * 7) % 20),
  color: ['#ff2d8d', '#20ddf5', '#8b36d9'][i % 3],
}));

export default function Backdrop() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 70% 40% at 50% -5%, rgba(255,45,141,0.35), transparent 70%),' +
            'radial-gradient(ellipse 50% 40% at 85% 10%, rgba(139,54,217,0.28), transparent 70%),' +
            'linear-gradient(180deg, #101426 0%, #0b1224 45%, #080d19 100%)',
        }}
      />
      {PARTICLES.map((p, i) => (
        <span
          key={i}
          className="dust absolute bottom-[-10px] rounded-full opacity-40"
          style={{ left: `${p.left}%`, width: p.size, height: p.size, background: p.color, animationDuration: `${p.duration}s`, animationDelay: `${p.delay}s` }}
        />
      ))}
    </div>
  );
}
