import { forwardRef, useImperativeHandle, useState } from 'react';

/** Floating tooltip. Updated imperatively (ref.show / ref.hide) so map hovering never re-renders the map. */
const Tooltip = forwardRef(function Tooltip(_, ref) {
  const [state, setState] = useState(null);
  useImperativeHandle(ref, () => ({
    show: (content, x, y) => setState({ content, x, y }),
    hide: () => setState(null),
  }), []);

  if (!state) return null;
  const flip = state.x > window.innerWidth - 260;
  return (
    <div
      className="pointer-events-none fixed z-30 rounded-xl border border-white/15 bg-navy/90 px-3.5 py-2.5 shadow-[0_0_24px_rgba(255,45,141,0.35)]"
      style={{ left: state.x + (flip ? -16 : 16), top: state.y + 14, transform: flip ? 'translateX(-100%)' : undefined }}
    >
      {state.content}
    </div>
  );
});

export default Tooltip;
