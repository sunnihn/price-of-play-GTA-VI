import { memo } from 'react';
import ClockFace from './ClockFace.jsx';
import { useSpin, spinDuration } from '../hooks/useSpin.js';
import { fmtHours } from '../lib/format.js';

/**
 * One clock per country. Idle hands show the real hours value (hour hand = hours, minute hand = fraction).
 * When `spinKey` fires the hands spin and the number counts up from 0 to the actual value.
 */
function ClockNode({ node, selected, showLabel, spinKey, reducedMotion, registerRef, onSelect, onHover, onLeave }) {
  const progress = useSpin(spinKey, spinDuration(node.hours), reducedMotion);
  const spinning = progress < 1;
  const shown = node.hours * progress;
  const size = node.r / 20;

  return (
    // Position and scale are written by WorldMap straight to the DOM (camera-dependent).
    <g ref={registerRef}>
      <g
        className="cursor-pointer"
        onClick={() => onSelect(node.iso3, [node.iso3])}
        onPointerMove={(e) => onHover(node, e)}
        onPointerLeave={onLeave}
      >
        <g transform={`scale(${size})`}>
          <ClockFace
            color={node.color}
            hourAngle={shown * 30}
            minuteAngle={shown * 360}
            alarm={selected}
            ringing={spinning}
            pulse={selected}
          />
        </g>
        {showLabel && (
          <text y={node.r + 8} textAnchor="middle" fontSize="5.5" fontWeight="800" fill="#f7f5fa" stroke="#080d19" strokeWidth="1.6" paintOrder="stroke">
            {node.name.toUpperCase()} · {fmtHours(shown)} JAM{node.isExtended ? ' (UPAH MIN.)' : ''}
          </text>
        )}
      </g>
    </g>
  );
}

export default memo(ClockNode);
