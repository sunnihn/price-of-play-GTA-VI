/** The only text at the top of the screen. */
export const TITLE = 'THE PRICE OF PLAY: BERAPA JAM KERJA UNTUK MEMBELI GTA VI DI SELURUH DUNIA?';

export default function Header() {
  const [lead, question] = TITLE.split(': ');
  return (
    <>
    <div className="pointer-events-none absolute inset-x-0 top-0 z-[9] h-32 bg-gradient-to-b from-ocean/85 via-ocean/40 to-transparent" aria-hidden="true" />
    <header className="pointer-events-none absolute left-4 top-3 z-10 max-w-[min(92vw,820px)] md:left-8 md:top-5">
      <h1 className="font-display leading-tight">
        <span
          className="block bg-gradient-to-r from-hot-pink via-magenta to-violet bg-clip-text text-2xl font-extrabold text-transparent drop-shadow-[0_0_18px_rgba(255,45,141,0.5)] md:text-4xl"
        >
          {lead}:
        </span>
        <span className="mt-1.5 block text-sm font-semibold text-soft/90 md:text-lg">{question}</span>
      </h1>
    </header>
    </>
  );
}
