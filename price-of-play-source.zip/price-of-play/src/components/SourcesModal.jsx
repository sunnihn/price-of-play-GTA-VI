import { sourceMetadata } from '../lib/data.js';

const NOTES = [
  'Harga GTA VI berasal dari agregator pihak ketiga (PlayStation Store, dicek 15 Nov 2026), belum diverifikasi langsung ke toko resmi.',
  'Pendapatan per jam berasal dari ILO (lewat Our World in Data) dalam dolar internasional harga 2021 (PPP), bukan mata uang lokal.',
  'Tahun pengamatan upah berbeda-beda antarnegara; lihat label kualitas data pada tiap negara.',
  'Jam kerja adalah ukuran setara pendapatan, bukan waktu menabung: pajak dan biaya hidup tidak dihitung.',
  'Jam amber dihitung dari upah minimum (batas hukum atau kesepakatan bersama), bukan upah rata-rata. Angka ini tidak ikut peringkat dan tidak boleh dibandingkan langsung dengan jam biru sampai merah muda.',
  'Upah minimum bulanan diubah ke per jam memakai rata-rata jam kerja per pekerja, bukan jam kerja pekerja upah minimum. Keterbandingan dinilai Terbatas atau Rendah.',
  'Tokoh, mobil, dan pesawat hanyalah ilustrasi dekoratif dan tidak mewakili data apa pun.',
];

/** Source references and methodology notes, opened from the detail panel. */
export default function SourcesModal({ onClose }) {
  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-ocean/80 p-4" onClick={onClose} role="dialog" aria-modal="true" aria-label="Sumber dan catatan data">
      <div className="max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-white/15 bg-navy p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between">
          <h2 className="text-xl font-extrabold text-hot-pink">SUMBER DAN CATATAN DATA</h2>
          <button type="button" onClick={onClose} className="rounded-lg border border-white/15 px-3 py-1 text-sm hover:border-hot-pink">Tutup</button>
        </div>
        <ul className="mt-3 space-y-1.5 text-sm text-soft/85">
          {NOTES.map((n) => <li key={n} className="flex gap-2"><span className="text-cyan-neon">▸</span>{n}</li>)}
        </ul>
        <h3 className="mt-5 text-sm font-bold tracking-widest text-soft">DAFTAR SUMBER</h3>
        <ul className="mt-2 space-y-2 text-xs">
          {sourceMetadata.log.map((s) => (
            <li key={`${s.variable_group}-${s.source}`} className="rounded-lg bg-white/5 p-2.5">
              <p className="font-semibold text-soft">{s.source}</p>
              <p className="text-soft/60">{s.variable_group} · tahun {s.observation_year} · {s.status}</p>
              {s.url?.startsWith('http') && (
                <a href={s.url} target="_blank" rel="noreferrer" className="break-all text-cyan-neon underline-offset-2 hover:underline">{s.url}</a>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
