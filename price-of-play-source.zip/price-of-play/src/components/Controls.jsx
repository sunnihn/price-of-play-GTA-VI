const btn = 'pointer-events-auto grid h-10 w-10 place-items-center rounded-xl border border-white/15 bg-navy/92 text-xl font-bold text-soft transition hover:border-hot-pink hover:text-hot-pink';

/** Zoom buttons for people without a wheel. */
export default function Controls({ onZoomIn, onZoomOut, onReset, shifted }) {
  return (
    <div className={`absolute bottom-4 z-10 flex flex-col gap-2 transition-all duration-500 ${shifted ? 'right-4 md:right-[392px]' : 'right-4 md:right-8'}`}>
      <button type="button" className={btn} onClick={onZoomIn} aria-label="Perbesar">+</button>
      <button type="button" className={btn} onClick={onZoomOut} aria-label="Perkecil">−</button>
      <button type="button" className={btn} onClick={onReset} aria-label="Lihat seluruh dunia">⌂</button>
    </div>
  );
}
