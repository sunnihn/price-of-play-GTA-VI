import { useEffect, useRef } from 'react';
import { arcPoint } from '../lib/arc.js';

const SPEED = { car: 38, plane: 62 }; // map units per second

function Car() {
  return (
    <g>
      <ellipse cx="0" cy="6.4" rx="19" ry="2.2" fill="#000" opacity="0.35" />
      <ellipse cx="0" cy="6" rx="16" ry="2" fill="#20ddf5" opacity="0.35" />
      <path d="M-22,-1 L-34,-1 M-21,2 L-30,2" stroke="#ff2d8d" strokeOpacity="0.5" strokeWidth="1" strokeLinecap="round" />
      <path d="M-20,4 L-20,0 Q-19,-2.5 -13,-3 L-7,-4 L-2,-8.5 Q2,-10 8,-9 L13,-4.5 L18,-3 Q20,-2 20,1 L20,4 Z" fill="url(#car-grad)" />
      <path d="M-1,-4.5 L2.5,-7.8 Q5,-8.4 8,-7.8 L11,-4.5 Z" fill="#bfeaff" opacity="0.9" />
      <rect x="-20" y="-0.4" width="2.4" height="1.8" rx="0.6" fill="#ff3b3b" />
      <ellipse cx="19.6" cy="0.6" rx="1.8" ry="1.2" fill="#fff6c7" />
      <path d="M20,0.6 L33,-2 L33,3.2 Z" fill="#fff6c7" opacity="0.18" />
      {[-12, 12].map((x) => (
        <g key={x}>
          <circle cx={x} cy="4.4" r="3.7" fill="#0d1020" />
          <circle cx={x} cy="4.4" r="1.9" fill="#cfd6e8" />
        </g>
      ))}
    </g>
  );
}

function Plane() {
  return (
    <g>
      <path d="M-22,0 L-46,0" stroke="url(#trail-grad)" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M6,-1.5 L-4,-17 L-9,-17 L-5,-1.5 Z" fill="#dfe3f0" />
      <path d="M6,1.5 L-4,17 L-9,17 L-5,1.5 Z" fill="#dfe3f0" />
      <path d="M-15,-1 L-20,-7 L-22.5,-7 L-19.5,-1 Z" fill="#dfe3f0" />
      <path d="M-15,1 L-20,7 L-22.5,7 L-19.5,1 Z" fill="#dfe3f0" />
      <path d="M21,0 Q14,-2.4 4,-2.4 L-14,-2.4 Q-21,-1.8 -21,0 Q-21,1.8 -14,2.4 L4,2.4 Q14,2.4 21,0 Z" fill="#f7f5fa" />
      <path d="M-14,0 L14,0" stroke="#ff2d8d" strokeWidth="0.9" />
      <circle cx="-6" cy="-10" r="1.5" fill="#8b36d9" />
      <circle cx="-6" cy="10" r="1.5" fill="#8b36d9" />
      <path d="M17,0 Q19,-1 21,0 Q19,1 17,0 Z" fill="#20ddf5" />
    </g>
  );
}

/**
 * One vehicle per route, moving along the arc. Positions are written straight to the DOM
 * inside a single requestAnimationFrame loop so React does not re-render every frame.
 */
export default function Vehicles({ routes, getK, paused }) {
  const refs = useRef([]);

  useEffect(() => {
    if (paused) return undefined;
    let frame;
    const tick = (now) => {
      const seconds = now / 1000;
      const scaleBase = getK() ** -0.75;
      routes.forEach((route, i) => {
        const node = refs.current[i];
        if (!node) return;
        const t = (seconds * SPEED[route.kind] / route.arc.length + route.phase) % 1;
        const { x, y, angle } = arcPoint(route.arc, t);
        const leftward = Math.abs(angle) > 90;
        const size = (route.kind === 'plane' ? 0.5 : 0.42) * scaleBase;
        const rotate = route.kind === 'car' && leftward ? angle - 180 : angle;
        const flip = route.kind === 'car' && leftward ? -1 : 1;
        node.setAttribute('transform', `translate(${x.toFixed(2)} ${y.toFixed(2)}) rotate(${rotate.toFixed(1)}) scale(${size * flip} ${size})`);
      });
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [routes, getK, paused]);

  return (
    <g pointerEvents="none">
      {routes.map((route, i) => (
        <g key={route.id} ref={(el) => { refs.current[i] = el; }}>
          {route.kind === 'plane' ? <Plane /> : <Car />}
        </g>
      ))}
    </g>
  );
}
