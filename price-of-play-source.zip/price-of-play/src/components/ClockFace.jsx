/**
 * Alarm-clock drawing in a radius-20 coordinate space (origin at the centre).
 * Hands are driven by angles so callers can animate them (idle, count-up spin).
 */
export default function ClockFace({ color, hourAngle, minuteAngle, alarm = false, ringing = false, pulse = false }) {
  const ticks = Array.from({ length: 12 }, (_, i) => i);
  return (
    <g>
      {alarm && (
        <g>
          <g className={ringing ? 'bells-ringing' : undefined}>
            <path d="M-14,-17 Q-19,-25 -10,-26 Q-7,-22 -9,-17 Z" fill="#c9cfe3" stroke="#6f7799" strokeWidth="0.8" />
            <path d="M14,-17 Q19,-25 10,-26 Q7,-22 9,-17 Z" fill="#c9cfe3" stroke="#6f7799" strokeWidth="0.8" />
            <line x1="0" y1="-20" x2="0" y2="-24" stroke="#6f7799" strokeWidth="1.2" />
            <circle cx="0" cy="-25" r="1.6" fill="#c9cfe3" />
          </g>
          <path d="M-13,17 L-18,25 M13,17 L18,25" stroke="#6f7799" strokeWidth="2.4" strokeLinecap="round" />
        </g>
      )}
      <circle r="23" fill="none" stroke={color} strokeWidth="4" opacity="0.4" className={pulse ? 'clock-glow' : undefined} />
      <circle r="20" fill={color} />
      <circle r="17.2" fill="url(#face-grad)" />
      {ticks.map((i) => (
        <line
          key={i}
          x1="0" y1={i % 3 === 0 ? -14 : -15.2} x2="0" y2="-16.4"
          stroke="#f7f5fa" strokeWidth={i % 3 === 0 ? 1.3 : 0.7} strokeLinecap="round"
          transform={`rotate(${i * 30})`}
        />
      ))}
      <line x1="0" y1="2" x2="0" y2="-8.5" stroke="#f7f5fa" strokeWidth="2.2" strokeLinecap="round" transform={`rotate(${hourAngle})`} />
      <line x1="0" y1="3" x2="0" y2="-13" stroke={color} strokeWidth="1.5" strokeLinecap="round" transform={`rotate(${minuteAngle})`} />
      <circle r="1.9" fill="#f7f5fa" />
    </g>
  );
}
