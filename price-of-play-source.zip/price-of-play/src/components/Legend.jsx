import { STOPS, MISSING_COLOR, EXT_COLOR } from '../lib/palette.js';
import { stats } from '../lib/data.js';
import { fmtHours } from '../lib/format.js';

export default function Legend() {
  const bar = `linear-gradient(90deg, ${STOPS.map((s) => `${s.color} ${s.at * 100}%`).join(', ')})`;
  return (
    <aside className="pointer-events-none absolute bottom-4 left-4 z-10 w-[min(88vw,300px)] rounded-2xl border border-white/10 bg-navy/90 p-3.5 md:left-8">
      <p className="text-[13px] font-bold leading-tight tracking-wide text-soft">JAM KERJA UNTUK MEMBELI GTA VI</p>
      <div className="mt-2.5 h-2.5 rounded-full" style={{ background: bar }} />
      <div className="mt-1.5 flex justify-between text-[11px] font-semibold text-soft/85">
        <span>{fmtHours(stats.min)} jam</span>
        <span>{fmtHours(stats.max)} jam</span>
      </div>
      <div className="mt-1 flex justify-between text-[9px] uppercase tracking-wide text-soft/50">
        {STOPS.map((s) => <span key={s.label}>{s.label}</span>)}
      </div>
      <div className="mt-2.5 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-wide text-soft/60">
        <span className="h-2.5 w-4 rounded-sm" style={{ background: MISSING_COLOR }} />
        Data belum tersedia (hanya harga)
      </div>
      <div className="mt-1.5 flex items-start gap-2 text-[10px] font-semibold uppercase tracking-wide text-soft/60">
        <span className="mt-0.5 h-2.5 w-4 shrink-0 rounded-sm" style={{ background: EXT_COLOR }} />
        Jam amber: pekerja upah minimum, tidak dibandingkan dengan skala di atas
      </div>
    </aside>
  );
}
