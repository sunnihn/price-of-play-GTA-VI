import { stats } from '../lib/data.js';
import { fmtHours, fmtUsd } from '../lib/format.js';

/** Tooltip for a country or clock. Always shows the real value, never the scaled height. */
export function CountryTip({ country }) {
  const hasHours = country.hours !== null;
  return (
    <div className="min-w-[170px]">
      <p className="text-base font-bold leading-none text-soft">{country.name.toUpperCase()}</p>
      {hasHours ? (
        <>
          <p className="mt-1.5 text-2xl font-extrabold leading-none text-hot-pink">{fmtHours(country.hours)} JAM KERJA</p>
          <p className="mt-1 text-[11px] font-semibold uppercase tracking-wide text-soft/70">
            Peringkat #{country.rank} dari {stats.comparable}
          </p>
        </>
      ) : country.extended ? (
        <>
          <p className="mt-1.5 text-2xl font-extrabold leading-none text-orange-hot">{fmtHours(country.extended.hours)} JAM</p>
          <p className="mt-1 text-[11px] font-semibold uppercase tracking-wide text-soft/70">Pekerja upah minimum, tampilan terpisah</p>
          <p className="mt-0.5 text-[11px] text-soft/60">Harga: {fmtUsd(country.master.gta_standard_usd)}</p>
        </>
      ) : (
        <>
          <p className="mt-1 text-sm font-bold uppercase tracking-wide text-soft/70">Data belum tersedia</p>
          <p className="mt-0.5 text-[11px] text-soft/60">Harga: {fmtUsd(country.master.gta_standard_usd)}</p>
        </>
      )}
    </div>
  );
}

