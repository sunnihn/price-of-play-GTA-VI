import { memo } from 'react';

const SKIN = ['#f1c27d', '#c68642', '#8d5524', '#ffdbac', '#e0ac69'];
const HOODIE = ['#ff2d8d', '#20ddf5', '#8b36d9', '#286bff', '#ff7a3d'];
const HAIR = ['#1b1420', '#4a2c1a', '#d8a657', '#2b2b3a'];

const pick = (list, seed, shift = 0) => list[(seed >> shift) % list.length];

/**
 * A seated player in front of a TV with a controller. Illustrated, decorative only:
 * it carries no data. Origin is the floor, centred between TV and couch.
 */
function Gamer({ seed }) {
  const skin = pick(SKIN, seed, 0);
  const hoodie = pick(HOODIE, seed, 2);
  const hair = pick(HAIR, seed, 4);
  return (
    <g>
      <ellipse cx="0" cy="0.5" rx="34" ry="2.6" fill="#000" opacity="0.35" />

      {/* TV with a sunset screen */}
      <rect x="-26" y="-4" width="10" height="4" rx="1" fill="#1b2038" />
      <rect x="-37" y="-27" width="28" height="22" rx="2.5" fill="#0d1124" stroke="#4a5280" strokeWidth="0.8" />
      <g className="tv-screen">
        <rect x="-35" y="-25" width="24" height="18" rx="1.5" fill="url(#tv-grad)" />
        <circle cx="-23" cy="-16" r="4.2" fill="#ffd36b" />
        <path d="M-35,-9 L-30,-14 L-26,-10 L-20,-15 L-11,-8 L-11,-7 L-35,-7 Z" fill="#2a0f4d" />
        <path d="M-17,-8 L-17,-17 M-17,-17 Q-21,-19 -23,-16 M-17,-17 Q-14,-20 -11,-17" stroke="#150a2b" strokeWidth="0.9" fill="none" />
      </g>

      {/* couch */}
      <rect x="14" y="-27" width="19" height="25" rx="4.5" fill="#4a1a80" />
      <rect x="-2" y="-11" width="35" height="10" rx="3.5" fill="#7a2fc0" />
      <rect x="-5" y="-15" width="7" height="14" rx="3.5" fill="#6a27ab" />
      <rect x="1" y="-2" width="3" height="2.5" fill="#2b0f4d" />
      <rect x="28" y="-2" width="3" height="2.5" fill="#2b0f4d" />

      {/* player */}
      <g className="gamer-body">
        <rect x="12.5" y="-31" width="9.5" height="20" rx="4.5" fill={hoodie} transform="rotate(-6 17 -21)" />
        <path d="M12.5,-23 Q17,-20 22,-23" stroke="#000" strokeOpacity="0.18" strokeWidth="1" fill="none" />
        <circle cx="16" cy="-35" r="5.2" fill={skin} />
        <path d="M10.6,-35.5 Q11,-41.5 17,-41 Q22,-40.5 21.4,-34 Q19,-37.5 15.5,-37 Q12.5,-36.5 10.6,-35.5 Z" fill={hair} />
        <circle cx="12.6" cy="-34.6" r="0.6" fill="#1b1420" />
        <path d="M11.2,-32.3 Q13,-31.4 14.6,-32.2" stroke="#7a3b2b" strokeWidth="0.5" fill="none" />
      </g>
      <rect x="3" y="-14" width="15" height="5.4" rx="2.7" fill="#2a3556" />
      <rect x="1.5" y="-12" width="5.4" height="12" rx="2.7" fill="#2a3556" />
      <rect x="-3" y="-3.6" width="10" height="3.8" rx="1.9" fill="#f7f5fa" />
      <path d="M15,-26 L9,-19 L3,-20.5" stroke={hoodie} strokeWidth="3.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <circle cx="2.6" cy="-20.6" r="1.8" fill={skin} />
      <g className="gamer-thumb">
        <rect x="-1.8" y="-23.6" width="8" height="4.4" rx="2.2" fill="#161a2c" />
        <circle cx="0.6" cy="-21.4" r="0.9" fill="#475082" />
        <circle cx="3.6" cy="-21.4" r="0.9" fill="#475082" />
        <circle cx="5" cy="-22.6" r="0.55" fill="#ff2d8d" />
      </g>
    </g>
  );
}

export default memo(Gamer);
