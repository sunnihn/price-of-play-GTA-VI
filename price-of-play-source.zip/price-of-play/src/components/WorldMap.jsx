import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import Countries, { CountryGradients } from './Countries.jsx';
import Vehicles from './Vehicles.jsx';
import ClockNode from './ClockNode.jsx';
import Gamer from './Gamer.jsx';
import Controls from './Controls.jsx';
import { CountryTip } from './MapTooltips.jsx';
import { useViewport } from '../hooks/useViewport.js';
import { graticulePath, loadCountryShapes, spherePath, VIEWBOX } from '../lib/geo.js';
import { countries, countryByIso, nodes, routes } from '../lib/data.js';

const GAMER_MIN_ZOOM = 2.6;
const LABEL_MIN_ZOOM = 5;
const SELECTED_BOOST = 1.35;

const dataIso = countries.map((c) => c.iso3);
const coarseShapes = loadCountryShapes('coarse', dataIso);
const fineShapes = loadCountryShapes('fine');
const shapeSize = Object.fromEntries(fineShapes.filter((s) => s.iso3).map((s) => [s.iso3, s.size]));
const seedOf = (iso) => [...iso].reduce((sum, ch) => sum + ch.charCodeAt(0), 0);

/** Clocks and figures shrink slower than the map grows, so they stay readable at every zoom. */
const sizeAt = (k) => k ** -0.55;

/**
 * Page 1: the flat world map.
 *
 * Performance note: the camera moves every frame, so its transform and the zoom-dependent
 * positions of clocks / figures are written straight to the DOM (see `applyCamera`).
 * React only re-renders on coarse changes (zoom bucket, selection, spinning clock).
 */
export default function WorldMap({ selectedIso, spin, onSelect, reducedMotion, tooltipRef, panelOpen, onReset }) {
  const svgRef = useRef(null);
  const worldRef = useRef(null);
  const gamerLayerRef = useRef(null);
  const clockRefs = useRef({});
  const gamerRefs = useRef({});
  const selectedRef = useRef(selectedIso);
  const hairlineTimer = useRef(0);
  const [zoomBucket, setZoomBucket] = useState(0); // 0 = far, 1 = figures visible, 2 = labels visible

  const applyCamera = useCallback((view) => {
    const { x, y, k } = view;
    worldRef.current?.setAttribute('transform', `translate(${x.toFixed(2)} ${y.toFixed(2)}) scale(${k.toFixed(4)})`);
    // Outline width is restyled only once the camera rests: changing a CSS variable
    // restyles every country, which is too costly to do on each frame.
    clearTimeout(hairlineTimer.current);
    hairlineTimer.current = setTimeout(() => worldRef.current?.style.setProperty('--hairline', (1 / k).toFixed(4)), 140);
    const s = sizeAt(k);
    const gamerSize = 1.1 * k ** -0.8;

    nodes.forEach((node) => {
      const px = node.anchor[0] + node.offset[0] * s;
      const py = node.anchor[1] + node.offset[1] * s;
      const boost = node.iso3 === selectedRef.current ? SELECTED_BOOST : 1;
      clockRefs.current[node.iso3]?.setAttribute('transform', `translate(${px.toFixed(2)} ${py.toFixed(2)}) scale(${(s * boost).toFixed(4)})`);
      gamerRefs.current[node.iso3]?.setAttribute(
        'transform',
        `translate(${(px + node.r * s + 24 * gamerSize).toFixed(2)} ${(py + node.r * s + 4 * gamerSize).toFixed(2)}) scale(${gamerSize.toFixed(4)})`,
      );
    });

    gamerLayerRef.current?.setAttribute('opacity', String(Math.min(1, Math.max(0, (k - GAMER_MIN_ZOOM + 0.2) / 1.2))));
    const bucket = k >= LABEL_MIN_ZOOM ? 2 : k >= GAMER_MIN_ZOOM ? 1 : 0;
    setZoomBucket((prev) => (prev === bucket ? prev : bucket));
  }, []);

  const { viewRef, focusOn, reset, zoomBy, pointerHandlers, wasDragged } = useViewport(svgRef, {
    reducedMotion,
    onFrame: applyCamera,
  });

  // Initial placement, and again whenever the selection (which enlarges one clock) changes.
  useLayoutEffect(() => {
    selectedRef.current = selectedIso;
    applyCamera(viewRef.current);
  }, [selectedIso, zoomBucket, applyCamera, viewRef]);

  // Fly to the selected country, or back out when the selection is cleared.
  useEffect(() => {
    if (!selectedIso) { reset(); return; }
    const zoom = Math.min(10, Math.max(2.8, 230 / (shapeSize[selectedIso] ?? 60)));
    focusOn(countryByIso[selectedIso].anchor, zoom);
  }, [selectedIso, focusOn, reset]);

  const handleSelect = useCallback((iso, targets) => {
    if (wasDragged()) return;
    onSelect(iso, targets);
  }, [onSelect, wasDragged]);

  const showCountryTip = useCallback((country, e) => {
    tooltipRef.current?.show(<CountryTip country={country} />, e.clientX, e.clientY);
  }, [tooltipRef]);

  const hideTip = useCallback(() => tooltipRef.current?.hide(), [tooltipRef]);

  // Selected clock last so it is drawn on top; otherwise small clocks sit above big ones.
  const orderedNodes = useMemo(
    () => [...nodes].sort((a, b) => (a.iso3 === selectedIso) - (b.iso3 === selectedIso) || b.hours - a.hours),
    [selectedIso],
  );

  const getK = useCallback(() => viewRef.current.k, [viewRef]);

  return (
    <>
      <svg
        ref={svgRef}
        viewBox={`${VIEWBOX.x} ${VIEWBOX.y} ${VIEWBOX.width} ${VIEWBOX.height}`}
        className="absolute inset-0 h-full w-full touch-none select-none"
        role="img"
        aria-label="Peta dunia jam kerja untuk membeli GTA VI"
        {...pointerHandlers}
      >
        <defs>
          <radialGradient id="face-grad" cx="50%" cy="40%" r="70%">
            <stop offset="0" stopColor="#222a52" />
            <stop offset="1" stopColor="#0c1022" />
          </radialGradient>
          <linearGradient id="tv-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#8b36d9" />
            <stop offset="0.6" stopColor="#ff2d8d" />
            <stop offset="1" stopColor="#ff9a4d" />
          </linearGradient>
          <linearGradient id="car-grad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#ff6bb4" />
            <stop offset="1" stopColor="#e6007e" />
          </linearGradient>
          <linearGradient id="trail-grad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#20ddf5" stopOpacity="0" />
            <stop offset="1" stopColor="#20ddf5" stopOpacity="0.9" />
          </linearGradient>
        </defs>
        <CountryGradients countries={countries} />

        <g ref={worldRef}>
          <path d={spherePath} fill="rgba(40,107,255,0.07)" />
          <path d={graticulePath} fill="none" stroke="rgba(32,221,245,0.09)" strokeWidth="0.5" vectorEffect="non-scaling-stroke" />
          <Countries shapes={zoomBucket >= 1 ? fineShapes : coarseShapes} selectedIso={selectedIso} onSelect={handleSelect} onHover={showCountryTip} onLeave={hideTip} />
          <Vehicles routes={routes} getK={getK} paused={reducedMotion} />

          {zoomBucket >= 1 && (
            <g ref={gamerLayerRef} pointerEvents="none">
              {nodes.map((node) => (
                <g key={node.iso3} ref={(el) => { gamerRefs.current[node.iso3] = el; }}>
                  <Gamer seed={seedOf(node.iso3)} />
                </g>
              ))}
            </g>
          )}

          {orderedNodes.map((node) => (
            <ClockNode
              key={node.iso3}
              node={node}
              selected={node.iso3 === selectedIso}
              showLabel={node.iso3 === selectedIso || zoomBucket >= 2}
              spinKey={spin.targets.includes(node.iso3) ? spin.key : 0}
              reducedMotion={reducedMotion}
              registerRef={(el) => { clockRefs.current[node.iso3] = el; }}
              onSelect={handleSelect}
              onHover={showCountryTip}
              onLeave={hideTip}
            />
          ))}
        </g>
      </svg>
      <Controls
        shifted={panelOpen}
        onZoomIn={() => zoomBy(1.7)}
        onZoomOut={() => zoomBy(1 / 1.7)}
        onReset={onReset}
      />
    </>
  );
}
