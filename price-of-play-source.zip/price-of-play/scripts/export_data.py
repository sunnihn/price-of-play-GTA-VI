"""Export GTA_VI_GLOBAL_DATA_2026.xlsx into JSON files used by the frontend.

Usage: python3 scripts/export_data.py path/to/GTA_VI_GLOBAL_DATA_2026.xlsx
ISO3 is the join key. Missing values stay null (never zero).
"""
import json
import sys
from pathlib import Path

from openpyxl import load_workbook

XLSX = sys.argv[1] if len(sys.argv) > 1 else "GTA_VI_GLOBAL_DATA_2026.xlsx"
OUT = Path(__file__).resolve().parent.parent / "src" / "data"
OUT.mkdir(parents=True, exist_ok=True)

wb = load_workbook(XLSX, data_only=True)


def clean(v):
    """Turn workbook 'Missing' markers and blanks into null."""
    if v is None or v == "" or v == "Missing":
        return None
    return v


def table(sheet, header_row):
    ws = wb[sheet]
    heads = [c.value for c in ws[header_row]]
    rows = []
    for r in ws.iter_rows(min_row=header_row + 1, values_only=True):
        if not r[0] or not isinstance(r[0], str):
            continue
        rows.append({h: clean(v) for h, v in zip(heads, r) if h})
    return rows


# Comparable_Analysis: only rows that are real ISO3 codes (notes below the table are skipped)
analysis = [r for r in table("Comparable_Analysis", 4) if len(r["iso3"]) == 3 and r["iso3"].isupper()]
master = [r for r in table("Master_Dataset", 4) if len(r["iso3"]) == 3]
wages = {r["iso3"]: r for r in table("Wages_Hours", 4) if r.get("iso3") and len(r["iso3"]) == 3}

# Merge wage definition fields into the analysis rows (same iso3 key)
for row in analysis:
    w = wages.get(row["iso3"], {})
    for key in ("wage_type", "wage_unit", "employee_coverage", "wage_source",
                "annual_working_hours", "working_hours_year"):
        row[key] = w.get(key)

REASON_ID = {
    "No ILO average hourly earnings": "Data upah rata-rata per jam (ILO) tidak ditemukan",
    "PPP factor is 2021": "Tahun faktor PPP (2021) tidak cocok dengan kurs 2025",
    "No World Bank PPP factor": "Faktor PPP Bank Dunia tidak tersedia",
}
missing = []
for r in table("Missing_Data_Report", 4):
    if len(r["iso3"]) != 3:
        continue
    reason = r.get("reason_excluded") or ""
    parts = [v for k, v in REASON_ID.items() if k in reason]
    missing.append({"iso3": r["iso3"], "reason_id": "; ".join(parts) or "Data pembanding tidak lengkap"})

ID_GROUP = {
    "JPN": "Seluruh pekerja (rata-rata tertimbang batas tiap prefektur)",
    "AUS": "Pekerja tanpa award atau perjanjian, usia dewasa",
    "POL": "Pekerja dengan kontrak perdata (umowa zlecenie)",
    "NZL": "Pekerja dewasa usia 16 tahun ke atas",
    "HKG": "Seluruh pekerja, kecuali kelompok tertentu",
    "TWN": "Pekerja dibayar per jam",
    "DNK": "Hanya pekerja industri dalam kesepakatan IO",
    "HRV": "Pekerja penuh waktu (upah minimum bulanan nasional)",
    "SGP": "Hanya petugas kebersihan warga negara dan penduduk tetap",
    "ARE": "Hanya warga Emirati di sektor swasta",
    "SAU": "Hanya warga Saudi yang dihitung dalam Nitaqat",
    "NIC": "Sektor manufaktur (ada sembilan upah minimum sektoral)",
    "ARG": "Pekerja dibayar per jam",
}
ID_NOTE = {
    "JPN": "Tarif FY2026 berlaku bertahap Oktober sampai Desember 2026. Angka yang dipakai adalah rata-rata nasional yang sudah berlaku.",
    "DNK": "Denmark tidak punya upah minimum menurut undang-undang. Angka ini hanya satu kesepakatan sektor.",
    "SGP": "Singapura tidak punya upah minimum nasional. Angka ini anak tangga terendah di sektor kebersihan.",
    "ARE": "Pekerja asing, yang menjadi mayoritas tenaga kerja, tidak punya batas minimum.",
    "SAU": "Pekerja asing tidak punya batas minimum.",
    "NIC": "Data jam kerja tahunan tidak tersedia, jadi dipakai asumsi 48 jam x 52 minggu.",
    "ARG": "Harga di toko dalam USD. Kurs resmi November 2026 dipakai karena peso kehilangan nilai riil dengan cepat.",
    "TWN": "Taiwan tidak punya data kurs atau PPP Bank Dunia. Tidak perlu di sini karena harga dan upah sama-sama dalam TWD.",
}
ID_METHOD = [
    ("COLLECTIVE", "Upah minimum per jam dari kesepakatan bersama"),
    ("SECTOR", "Upah minimum bulanan sektoral, diubah ke per jam"),
    ("NATIONALS", "Upah minimum bulanan warga negara, diubah ke per jam"),
    ("ESTIMATED_FROM_MONTHLY", "Upah minimum bulanan, diubah ke per jam"),
    ("LEGAL_MIN_HOURLY", "Upah minimum per jam menurut aturan"),
]
ID_VERIF = [("Official", "Sumber resmi"), ("Secondary", "Sumber sekunder")]


def first(table_map, text, default):
    return next((v for k, v in table_map if k in (text or "")), default)


extended = []
for r in table("Extended_Coverage", 4):
    if len(r.get("iso3") or "") != 3:
        continue
    extended.append({
        "iso3": r["iso3"],
        "hours": r["WORK_HOURS_MIN_WAGE"],
        "rank": r["rank_extended_fewest_hours"],
        "wage_value": r["min_wage_value"],
        "wage_currency": r["wage_currency"],
        "wage_period": r["wage_period"],
        "hourly_wage": r["hourly_min_wage_lcu"],
        "year": r["replacement_year"],
        "method_id": first(ID_METHOD, r["replacement_method"], "Upah minimum"),
        "verification_id": first(ID_VERIF, r["verification_status"], "Belum diverifikasi"),
        "comparability": r["comparability_flag"],
        "group_id": ID_GROUP.get(r["iso3"]),
        "note_id": ID_NOTE.get(r["iso3"]),
        "source_url": r["source_url"],
    })

sources = {
    "log": [r for r in table("Source_Log", 3)],
    "audit": [r for r in table("Data_Quality_Audit", 3) if r.get("severity") in ("important", "warn")],
}

for name, payload in {
    "country_analysis": analysis,
    "country_master": master,
    "missing_report": missing,
    "extended_coverage": extended,
    "source_metadata": sources,
}.items():
    (OUT / f"{name}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=1))

print(f"analysis={len(analysis)} master={len(master)} missing={len(missing)} sources={len(sources['log'])} extended={len(extended)}")
