# The Price of Play: peta jam kerja untuk membeli GTA VI

React + Vite + Tailwind v4. Peta dunia 2D (d3-geo, SVG) dengan rute antarnegara, jam alarm, pemain, mobil, dan pesawat.

## Menjalankan
```bash
npm install
npm run dev        # pengembangan
npm run build      # hasil: dist/index.html (satu file, bisa dibuka langsung)
```

## Data
Semua angka dibaca dari `GTA_VI_GLOBAL_DATA_2026.xlsx`; tidak ada angka di dalam komponen.
```bash
python3 scripts/export_data.py path/ke/GTA_VI_GLOBAL_DATA_2026.xlsx   # menulis src/data/*.json
```
Kunci gabung = ISO3. Nilai kosong tetap `null` (tidak pernah dijadikan nol).

## Struktur
- `src/lib` — data, palet, geometri peta, busur rute, tata letak jam
- `src/hooks` — kamera (zoom/geser), animasi putar jam, reduced motion
- `src/components` — WorldMap, Routes, Vehicles, ClockNode/ClockFace, Gamer, DetailPanel, dll.

Judul ada di `src/components/Header.jsx` (konstanta `TITLE`).
