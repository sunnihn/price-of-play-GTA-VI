import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

// Single-file build: one self-contained index.html that opens without a server.
export default defineConfig({
  plugins: [react(), tailwindcss(), viteSingleFile()],
});
